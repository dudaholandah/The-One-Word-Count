package theone;

public interface TFFunction {
	String[] doSomething(String[] param);
}
